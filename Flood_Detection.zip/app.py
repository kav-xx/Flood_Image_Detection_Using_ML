from flask import Flask, request, jsonify, render_template
from tensorflow import keras
import cv2
import numpy as np
import os

app = Flask(__name__)

# Load the trained model (update the path to the actual model file)
model = keras.models.load_model(r'C:\Users\91720\Documents\SDP II\cnn_pepper_ifp.h5')

def preprocess_image(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (128, 128))
    img = np.expand_dims(img, axis=0)
    img = img / 255.0
    return img


@app.home('/home')
def page():
    return render_template('home.html')  #Render front page

@app.home('/login')
def loginpage():

@app.route('/')
def home():
    return render_template('index.html')  # Render the home page

@app.route('/upload')
def upload_page():
    return render_template('upload.html')  # Render the upload page

@app.route('/predict', methods=['POST'])
def predict():
    try:
        file = request.files['image']  # Access the uploaded image

        # Save the image to a specific path (temporary storage)
        image_path = 'test_pepperbacterialspot.jpg'
        file.save(image_path)

        # Preprocess the image
        processed_image = preprocess_image(image_path)

        # Predict using the model
        logits = model.predict(processed_image)
        probability = 1 / (1 + np.exp(-logits))

        # Remove the image after prediction
        os.remove(image_path)

        prediction = 'Flooded' if probability >= 0.5 else 'Not Flooded'

        # Return prediction and probability as JSON (for upload.js)
        return jsonify({'prediction': prediction, 'probability': float(probability[0][0]), 'status': 'success'})
    
    except Exception as e:
        return jsonify({'error': str(e), 'status': 'failure'})

if __name__ == '__main__':
    app.run(debug=True)

if __name__=='__main__':
    app.run(debug=False)